<?php

/**
 * data
 * @author auto create
 */
class MapData
{
	
	/** 
	 * password
	 **/
	public $model;	
}
?>