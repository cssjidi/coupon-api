<?php
// Heading
$_['heading_title']    = 'FAQs Category';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified FAQs category module!';
$_['text_edit']        = 'Edit FAQs Category Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify FAQs category module!';